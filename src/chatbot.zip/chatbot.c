#include <stdio.h>
#include <string.h>
#include "chatbot.h"
#include <stdlib.h>


 typedef struct chatbot
 {
     char line[LINELENGTH];

 }p;

void add(void){
    int x,y;
    printf("What are the digits that you want to add :");
    scanf("%d %d", &x,&y);
    printf("%d",x+y);
}


void divide(void)
{
    int t,h;
    printf("What are the digits that you want to subtract :");
    scanf("%d %d",&t,&h);
    printf("%d",t/h);
}


void multiply(void)
{
    int r,f;
    printf("What are the digits that you want to subtract :");
    scanf("%d %d",&r,&f);
    printf("%d",r*f);
}



void subtract(void)
{
    int b,c;
    printf("What are the digits that you want to subtract :");
    scanf("%d %d",&b,&c);
    printf("%d",b-c);
}


int main(void) {
    system("COLOR FC");
    struct p;
  char line[LINELENGTH];
  char *word;

  printf("\n Rukia v0.0.1!\n\n");

  while(1) {
    fgets(line, LINELENGTH, stdin);
    if (strlen(line) <= 1) break; /*exit program*/
    word = strtok(line, SEPCHARS); /*Find first word */
    while (word != NULL) {
      // Some responses based on the keywords
      if (strncmp(word, "hi", 50) == 0) {
        printf("> %s\n","Hello" );
        break;
      }
      else if (strncmp(word, "coding", 50) == 0) {
        printf("> %s\n","Yes, I love programming!" );
        break;
      }
       else if (strncmp(word, "name", 50) == 0) {
        printf("> %s\n","My name is Rukia" );
        break;
      }
      else if (strncmp(word, "work", 50) == 0) {
        FILE *fp=fopen;
        break;
      }
      else if (strncmp(word, "creator", 50) == 0) {
        printf("> %s\n","1.A.K.M. Moinul Islam \n 2.Mahmudul Hasan Shihab \n 3.MD. Zahid Hossain Bhuiyan" );
        break;
      }
      else if (strncmp(word, "hear", 50) == 0) {
        printf("> %s\n","What you heard is right" );
        break;
      }
      else if (strncmp(word, "python", 50) == 0) {
        printf("> %s\n","Yo, I love Python" );
        break;
      }
      else if (strncmp(word, "?", 50) == 0) {
        printf("> %s\n","Is that a question ?" );
        break;
      }
      else if (strncmp(word, "add", 50) == 0) {
        add();
        break;
      }
       else if (strncmp(word, "divide", 50) == 0) {
        divide();
        break;
      }
      else if (strncmp(word, "subtract", 50) == 0) {
        subtract();
        break;
      }
       else if (strncmp(word, "multiply", 50) == 0) {
        multiply();
        break;
      }
      else if  (strncmp(word, "love", 50) == 0) {
        printf("> %s\n","Yes I love it" );
        break;
      }
      else if  (strncmp(word, "How", 50) == 0) {
        printf("> %s\n","Oh, now you don't know lair!" );
        break;
      }
      else if  (strncmp(word, "What", 50) == 0) {
        printf("> %s\n","It is clear, ain't it?" );
        break;
      }
      else if (strncmp(word, "loveyou", 50) == 0) {
        printf("> %s\n","I love you too" );
        break;
      }
       else if (strncmp(word, "sorry", 50) == 0) {
        printf("> %s\n","Are you really Sorry?" );
        break;
      }
       else if (strncmp(word, "doing", 50) == 0) {
        printf("> %s\n", "How can you do that?" );
        break;
      }
       else if (strncmp(word, "light", 50) == 0) {
         printf("> %s\n", "U meant light my fire by Jim Morrison ?");
         break;
       }
       else if  (strncmp(word, "bae", 50) == 0) {
        printf("> %s\n","Are u talking about Esha ?" );
        break;
       }
       else if  (strncmp(word, "forever", 50) == 0) {
        printf("> %s\n","Alvi of course :3" );
        break;
       }
        else if  (strncmp(word, "gram", 50) == 0) {
        printf("> %s\n","I guess it's Nushrat" );
        break;
       }
       else if  (strncmp(word, "saddest", 50) == 0) {
        printf("> %s\n","Sara the Dark one" );
        break;
       }
        else if  (strncmp(word, "mean", 50) == 0) {
        printf("> %s\n","Sadratul Meantaha ?" );
        break;
       }
        else if  (strncmp(word, "around", 50) == 0) {
        printf("> %s\n","alvi ?" );
        break;
       }
       else if  (strncmp(word, "around", 50) == 0) {
        printf("> %s\n","Imran everyone knows it :3" );
        break;
       }
       else if  (strncmp(word, "mom's", 50) == 0) {
        printf("> %s\n","Esha the showoff one ?" );
        break;
       }
       else if  (strncmp(word, "kala", 50) == 0) {
        printf("> %s\n","Sallu the kala pola" );
        break;
       }
         else if  (strncmp(word, "diva", 50) == 0) {
        printf("> %s\n","HHHHEEEREEE COMESSS THEE WWE DIVA CHAMPION NUUUUUUUUUUSHRAT THE SHUKNA FIGHTER" );
        break;
       }
        else if  (strncmp(word, "private", 50) == 0) {
        printf("> %s\n","SHANA THE PRIVATE ONE" );
        break;
       }
                else if  (strncmp(word, "exit", 50) == 0) {
        return 0;
        break;
       }


//      else {
//        printf("> %s\n", "Sorry, I don't know what to say about that" );
//        bruck eak;
//      }
      // printf("\"%s\"\n", word);
      word = strtok(NULL, SEPCHARS);
    }
  }
}

